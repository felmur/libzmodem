#!/bin/sh
./configure CFLAGS="-march=westmere -ggdb -Og -Wall -Wextra -fdiagnostics-color=auto"
