double timing __P ((int reset,time_t *now));
